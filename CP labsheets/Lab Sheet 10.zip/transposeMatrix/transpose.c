//transpose.c

//implement this function as defined in transpose.h
void transposeByReference(int matrix[4][4]){
    
}


//implement this function as defined in transpose.h
void transposeByPointer(int* matrix){
   
}