
//complete this function based on the definitions in reverseArray.h
void reverseArray_PassByPointers(int* arr, int size, int x){
    
}