
//complete this function based on the definitions in reverseArray.h
void reverseArray_PassByReference(int arr[], int size, int x){
    
}