#include "linkedList.h"

void printNode(NODE n1){
    
}

void printList(LIST l1){
    
}

LIST createNewList(){
	
}

NODE createNewNode(int value){
	
}


void insertNodeIntoList(NODE n1, LIST l1){
	
}

void insertNodeAtEnd(NODE n1, LIST l1){
    
}


NODE search(LIST l1, int value){
    
}

void insertAfter(int searchEle, NODE n1, LIST l1){
     
}

void removeFirstNode(LIST l1){
    
}

void removeLastNode(LIST l1){
    

}

void removeElem(int value, LIST l1){
    
 
}